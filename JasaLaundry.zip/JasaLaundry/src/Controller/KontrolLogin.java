/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import javax.swing.JOptionPane;
import Model.Akun;
import view.Admin;
import view.Login;
import view.User;
/**
 *
 * @author ROG
 */
public class KontrolLogin {
    //pengecekan akun
    public void ceklogin(String username, String password) {
        //instansiasi loginsebagi bagina dari akunmodel
        Akun login = new Akun();
        //pengerjaan method cek pada akunmodel dengan paramater yang diinput user
        login.cek( username, password);
    }

    //pengecekan login useer atau admin
    public void role(String role) {
        if ("admin".equals(role)){
            new Admin().show();
        }else if("user".equals(role)){
            new User().show();
        }else{
            String ERROR_MESSAGE = "username/password salah";
            JOptionPane.showMessageDialog(null,ERROR_MESSAGE);
            new Login().show();
        }
    }
}
