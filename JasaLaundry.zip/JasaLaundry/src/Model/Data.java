/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import Connector.Koneksi;
import Connector.Koneksi;
import javax.swing.JOptionPane;
import java.sql.SQLException;
/**
 *
 * @author ROG
 */
public class Data {
     public void update(String id, String nama, String hp, String tanggal, String kg, String biaya, String bayar, String alamat) {
        Koneksi k = new Koneksi();
        try {
            k.statement = k.koneksi.createStatement();
            k.statement.executeUpdate("UPDATE data set " 
            + "nama     ='"     + nama    + "', "
            + "no_hp    ='"     + hp      + "', "
            + "tanggal  ='"     + tanggal + "', "
            + "kg       ='"     + kg      + "', "
            + "biaya    ='"     + biaya   + "', "        
            + "total    ='"     + bayar   + "', "  
            + "alamat   ='"     + alamat  + "'  "
            + "WHERE id_pemesanan ='" +id+  "'");
        
        } catch (Exception e) {
        e.printStackTrace();
      }
    }

    //methode delete
    public void done(String id) {
         Koneksi k = new Koneksi();
        int jawab;
        try {
            if ((jawab = JOptionPane.showConfirmDialog(null, "Laundry telah selesai, ingin menghapus data?", "konfirmasi", JOptionPane.YES_NO_OPTION)) == 0) {
                k.statement = k.koneksi.createStatement();
                k.statement.executeUpdate("DELETE FROM data WHERE id_pemesanan='" +id+ "'");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //methode simpan
    public void simpan(String nama, String hp, String tanggal, String kg, String biaya, String bayar, String alamat) {
        Koneksi k = new Koneksi();
        try {
            String query = "INSERT INTO `data`(`nama`, `no_hp`,`tanggal`, `kg`, `biaya`, `total`,`alamat`)"
                           +" VALUES ('"+nama+"','"+hp+"','"+tanggal+"','"+kg+"','"+biaya+"','"+bayar+"','"+alamat+"')";
            k.statement = k.koneksi.createStatement();
            k.statement.executeUpdate(query);
        
        } catch (Exception e) {
        e.printStackTrace();
      }
    }
}
