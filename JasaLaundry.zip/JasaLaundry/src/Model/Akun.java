/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import Connector.Koneksi;
import Connector.Koneksi;
import Controller.KontrolLogin;
/**
 *
 * @author ROG
 */
public class Akun {
     public String role;
    
    //method untuk cek akun
    public void cek(String username, String password) {
        Koneksi k = new Koneksi();
        //instansiai masuk sebagai bagian dari class controllerlogin
        KontrolLogin masuk = new KontrolLogin();
        try{
            String query = "SELECT * FROM `login` WHERE username ='"+username+"' AND password='"+password+"'";
            k.statement = k.koneksi.createStatement();
            k.resultSet = k.statement.executeQuery(query);
            
            while(k.resultSet.next()){
                role = k.resultSet.getString("role");
            }
            //pengerjaan method role pada controller masuk dengan paramater role
            masuk.role(role);
        }
        catch(java.sql.SQLException e){
        }
    }
    
    //proses daftar user
    public void insertdaftar(String username, String password) {
        Koneksi k = new Koneksi();
        
        try{
            String query = "INSERT INTO `login`(`username`, `password`) VALUES ('"+username+"','"+password+"')";
            k.statement = k.koneksi.createStatement();
            k.statement.executeUpdate(query);
        }
        catch (java.sql.SQLException e){
        }
    }
}
